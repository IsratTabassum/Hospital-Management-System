package hospital;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

class Patient {
    private static int idCounter = 1000;
    private int patientId;
    private String name;
    private String medicalHistory;

    public Patient(String name, String medicalHistory) {
        this.patientId = idCounter++;
        this.name = name;
        this.medicalHistory = medicalHistory;
    }

    public int getPatientId() {
        return patientId;
    }

    public String getName() {
        return name;
    }

    public String getMedicalHistory() {
        return medicalHistory;
    }

    @Override
    public String toString() {
        return "Patient ID: " + patientId + "\nName: " + name + "\nMedical History: " + medicalHistory;
    }
}

class PatientService {
    private Map<Integer, Patient> patientMap;

    public PatientService() {
        patientMap = new HashMap<>();
    }

    public void registerPatient(Patient patient) {
        patientMap.put(patient.getPatientId(), patient);
    }

    public Patient getPatient(int patientId) {
        return patientMap.get(patientId);
    }

    public List<Patient> getAllPatients() {
        return new ArrayList<>(patientMap.values());
    }
}

class Doctor {
    private String name;
    private List<Prescription> prescriptions;

    public Doctor(String name) {
        this.name = name;
        this.prescriptions = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void writePrescription(Patient patient, String medication, String dosage) {
        Prescription prescription = new Prescription(patient.getPatientId(), medication, dosage);
        prescriptions.add(prescription);
    }

    public List<Prescription> getPrescriptions() {
        return prescriptions;
    }

    @Override
    public String toString() {
        return "Doctor Name: " + name;
    }
}

class DoctorService {
    private List<Doctor> doctors;

    public DoctorService() {
        doctors = new ArrayList<>();
    }

    public void registerDoctor(Doctor doctor) {
        doctors.add(doctor);
    }

    public Doctor getDoctor(String name) {
        for (Doctor doctor : doctors) {
            if (doctor.getName().equals(name)) {
                return doctor;
            }
        }
        return null;
    }

    public List<Doctor> getAllDoctors() {
        return doctors;
    }
}

class Pharmacy {
    private Map<Integer, List<Prescription>> prescriptionMap;

    public Pharmacy() {
        prescriptionMap = new HashMap<>();
    }

    public void addPrescription(Prescription prescription) {
        if (!prescriptionMap.containsKey(prescription.getPatientId())) {
            prescriptionMap.put(prescription.getPatientId(), new ArrayList<>());
        }
        prescriptionMap.get(prescription.getPatientId()).add(prescription);
    }

    public List<Prescription> getPrescriptions(int patientId) {
        return prescriptionMap.getOrDefault(patientId, new ArrayList<>());
    }
}


class PharmacyService {
    private Pharmacy pharmacy;

    public PharmacyService() {
        pharmacy = new Pharmacy();
    }

    public void addPrescription(Prescription prescription) {
        pharmacy.addPrescription(prescription);
    }

    public List<Prescription> getPrescriptions(int patientId) {
        return pharmacy.getPrescriptions(patientId);
    }
}


class Prescription {
    private int patientId;
    private String medication;
    private String dosage;

    public Prescription(int patientId, String medication, String dosage) {
        this.patientId = patientId;
        this.medication = medication;
        this.dosage = dosage;
    }

    public int getPatientId() {
        return patientId;
    }

    public String getMedication() {
        return medication;
    }

    public String getDosage() {
        return dosage;
    }
    @Override
    public String toString() {
        return "Patient ID: " + patientId + "\nMedication: " + medication + "\nDosage: " + dosage;
    }
}


class Medicine {
    private String name;
    private String manufacturer;
    private double price;

    public Medicine(String name, String manufacturer, double price) {
        this.name = name;
        this.manufacturer = manufacturer;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Medicine Name: " + name + "\nManufacturer: " + manufacturer + "\nPrice: $" + price;
    }
}

class MedicineService {
    private List<Medicine> medicines;

    public MedicineService() {
        medicines = new ArrayList<>();
    }

    public void addMedicine(Medicine medicine) {
        medicines.add(medicine);
    }

    public List<Medicine> getAllMedicines() {
        return medicines;
    }
}
class HospitalLoginPage extends JFrame {
	private static final long serialVersionUID = 1L;
	private JTextField usernameField;
    private JPasswordField passwordField;

    public HospitalLoginPage() {
        setTitle("Hospital Management System - Login");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 2, 10, 10));

        JLabel usernameLabel = new JLabel("Username:");
        add(usernameLabel);

        usernameField = new JTextField();
        add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        add(passwordLabel);

        passwordField = new JPasswordField();
        add(passwordField);

        JButton loginButton = new JButton("Login");
        add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (username.equals("Luna") && password.equals("5413")) {
                    dispose(); 
                    hospital window = new hospital();
                    window.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.");
                }
            }
        });

        setVisible(true);
    }

   
}

public class hospital extends JFrame implements Serializable {
    private static final long serialVersionUID = 1L;

    private JButton registerPatientButton;
    private JButton registerDoctorButton;
    private JButton viewPatientRecordButton;
    private JButton addMedicineButton;
    private JButton viewAllPatientsButton;
    private JButton viewAllDoctorsButton;
    private JButton viewAllMedicinesButton;
    private JTextArea outputTextArea;

    private PatientService patientService;
    private DoctorService doctorService;
    private PharmacyService pharmacyService;
    private MedicineService medicineService;
    private JButton writePrescriptionButton;
    private JButton viewPrescriptionsButton;

    public hospital() {
    	getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 13));
    	getContentPane().setBackground(new Color(176, 176, 176));
        setTitle("Hospital Management System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        patientService = new PatientService();
        doctorService = new DoctorService();
        pharmacyService = new PharmacyService();
        medicineService = new MedicineService();

        initializeComponents();
        setupListeners();

        setVisible(true);
    }

    private void initializeComponents() {
        
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setBounds(20, 0, 550, 50);
        titlePanel.setBackground(new Color(168, 153, 167));
        
       
        ImageIcon logoIcon = new ImageIcon("images/logo.png");
        getContentPane().setLayout(null);
        JLabel logoLabel = new JLabel(logoIcon);
        
       
        JLabel titleLabel = new JLabel("HOSPITAL MANAGEMENT SYSTEM");
        titleLabel.setForeground(new Color(0, 4, 60));
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        
        titlePanel.add(logoLabel);
        titlePanel.add(titleLabel);
        
        
        getContentPane().add(titlePanel);

        registerPatientButton = new JButton("Register Patient");
        registerPatientButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        registerPatientButton.setBounds(20, 60, 150, 30);
        registerPatientButton.setBackground(new Color(148, 163, 149));
        registerPatientButton.setForeground(new Color(0, 0, 0));
        getContentPane().add(registerPatientButton);

        registerDoctorButton = new JButton("Register Doctor");
        registerDoctorButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        registerDoctorButton.setBounds(200, 60, 150, 30);
        registerDoctorButton.setBackground(new Color(148, 163, 149));
        registerDoctorButton.setForeground(new Color(0, 0, 0));
        getContentPane().add(registerDoctorButton);

        viewPatientRecordButton = new JButton("View Patient Record");
        viewPatientRecordButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        viewPatientRecordButton.setBounds(380, 60, 150, 30);
        viewPatientRecordButton.setBackground(new Color(148, 163, 149));
        viewPatientRecordButton.setForeground(new Color(0, 0, 0));
        getContentPane().add(viewPatientRecordButton);

        addMedicineButton = new JButton("Add Medicine");
        addMedicineButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        addMedicineButton.setBounds(20, 110, 150, 30);
        addMedicineButton.setBackground(new Color(148, 163, 149));
        addMedicineButton.setForeground(new Color(0, 0, 0));
        getContentPane().add(addMedicineButton);

        viewAllPatientsButton = new JButton("View All Patients");
        viewAllPatientsButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        viewAllPatientsButton.setBounds(200, 110, 150, 30);
        viewAllPatientsButton.setBackground(new Color(148, 163, 149));
        viewAllPatientsButton.setForeground(new Color(0, 0, 0));
        getContentPane().add(viewAllPatientsButton);

        viewAllDoctorsButton = new JButton("View All Doctors");
        viewAllDoctorsButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        viewAllDoctorsButton.setBounds(380, 110, 150, 30);
        viewAllDoctorsButton.setBackground(new Color(148, 163, 149));
        viewAllDoctorsButton.setForeground(new Color(0, 0, 0));
        getContentPane().add(viewAllDoctorsButton);

        viewAllMedicinesButton = new JButton("View All Medicines");
        viewAllMedicinesButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        viewAllMedicinesButton.setBounds(20, 160, 150, 30);
        viewAllMedicinesButton.setBackground(new Color(148, 163, 149));
        viewAllMedicinesButton.setForeground(new Color(0, 0, 0));
        getContentPane().add(viewAllMedicinesButton);

        outputTextArea = new JTextArea();
        outputTextArea.setBounds(20, 210, 550, 150);
        outputTextArea.setBackground(new Color(200, 183, 199));
        outputTextArea.setEditable(false);
        getContentPane().add(outputTextArea);
        
        writePrescriptionButton = new JButton("Write Prescription");
        writePrescriptionButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        writePrescriptionButton.setBounds(200, 160, 150, 30);
        writePrescriptionButton.setBackground(new Color(148, 163, 149));
        writePrescriptionButton.setForeground(new Color(0, 0, 0));
        getContentPane().add(writePrescriptionButton);

        viewPrescriptionsButton = new JButton("View Prescriptions");
        viewPrescriptionsButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
        viewPrescriptionsButton.setBounds(380, 160, 150, 30);
        viewPrescriptionsButton.setBackground(new Color(148, 163, 149));
        viewPrescriptionsButton.setForeground(new Color(0, 0, 0));
        getContentPane().add(viewPrescriptionsButton);
    }

    private void setupListeners() {
        registerPatientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = JOptionPane.showInputDialog("Enter patient name:");
                String medicalHistory = JOptionPane.showInputDialog("Enter patient medical history:");
                Patient patient = new Patient(name, medicalHistory);
                patientService.registerPatient(patient);
                outputTextArea.setText("Patient Registered:\n" + patient.toString());
            }
        });

        registerDoctorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = JOptionPane.showInputDialog("Enter doctor name:");
                Doctor doctor = new Doctor(name);
                doctorService.registerDoctor(doctor);
                outputTextArea.setText("Doctor Registered:\n" + doctor.toString());
            }
        });

        viewPatientRecordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int patientId = Integer.parseInt(JOptionPane.showInputDialog("Enter patient ID:"));
                Patient patient = patientService.getPatient(patientId);
                if (patient != null) {
                    outputTextArea.setText("Patient Record:\n" + patient.toString());
                } else {
                    outputTextArea.setText("Patient not found.");
                }
            }
        });

        addMedicineButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = JOptionPane.showInputDialog("Enter medicine name:");
                String manufacturer = JOptionPane.showInputDialog("Enter manufacturer:");
                double price = Double.parseDouble(JOptionPane.showInputDialog("Enter price:"));
                Medicine medicine = new Medicine(name, manufacturer, price);
                medicineService.addMedicine(medicine);
                outputTextArea.setText("Medicine Added:\n" + medicine.toString());
            }
        });

        viewAllPatientsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Patient> patients = patientService.getAllPatients();
                StringBuilder sb = new StringBuilder();
                for (Patient patient : patients) {
                    sb.append(patient.toString()).append("\n\n");
                }
                outputTextArea.setText("All Patients:\n" + sb.toString());
            }
        });

        viewAllDoctorsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Doctor> doctors = doctorService.getAllDoctors();
                StringBuilder sb = new StringBuilder();
                for (Doctor doctor : doctors) {
                    sb.append(doctor.toString()).append("\n\n");
                }
                outputTextArea.setText("All Doctors:\n" + sb.toString());
            }
        });

        viewAllMedicinesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Medicine> medicines = medicineService.getAllMedicines();
                StringBuilder sb = new StringBuilder();
                for (Medicine medicine : medicines) {
                    sb.append(medicine.toString()).append("\n\n");
                }
                outputTextArea.setText("All Medicines:\n" + sb.toString());
            }
        });
        
        writePrescriptionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int patientId = Integer.parseInt(JOptionPane.showInputDialog("Enter patient ID:"));
                String medication = JOptionPane.showInputDialog("Enter medication:");
                String dosage = JOptionPane.showInputDialog("Enter dosage:");
                Doctor doctor = doctorService.getAllDoctors().get(0); 
                doctor.writePrescription(patientService.getPatient(patientId), medication, dosage);
                Prescription prescription = new Prescription(patientId, medication, dosage);
                pharmacyService.addPrescription(prescription);
                outputTextArea.setText("Prescription Written:\n" + prescription.toString());
            }
        });

        viewPrescriptionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int patientId = Integer.parseInt(JOptionPane.showInputDialog("Enter patient ID:"));
                List<Prescription> prescriptions = pharmacyService.getPrescriptions(patientId);
                StringBuilder sb = new StringBuilder();
                for (Prescription prescription : prescriptions) {
                    sb.append(prescription.toString()).append("\n\n");
                }
                if (sb.length() > 0) {
                    outputTextArea.setText("Prescriptions for Patient ID " + patientId + ":\n" + sb.toString());
                } else {
                    outputTextArea.setText("No prescriptions found for Patient ID " + patientId);
                }
            }
        });
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
            	  
                try {
                    new HospitalLoginPage();
                } catch (Exception e) {
                    e.printStackTrace();
               }
            }
        });
    }
}
